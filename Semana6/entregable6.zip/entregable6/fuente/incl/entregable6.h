#include <stdio.h>
#include <stdlib.h>
#include <unistd.h> 
#include <sys/stat.h>
#include <string.h>
#include <errno.h>
#include <time.h>
int esperaComando(char *, char *);
void checaCaracteres(char *);